# Chai Bikaner POS — Android Studio Project

A small-cafe, offline-first Android billing and POS starter app. Built with Java and native Android UI (no third-party runtime libraries).

## Included
- Billing cart and complete-sale workflow
- Menu with prices and opening stock for tea, coffee and snacks
- Inventory: restock, edit prices, add menu items
- Sales history and all-time/last-24-hours sales totals
- Expense log
- Local persistence using Android SharedPreferences; no internet required
- Bluetooth receipt printing to paired ESC/POS-compatible SPP thermal printers
- Non-GST receipt format

## Open and build
1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Open this folder (`ChaiBikanerAndroid`) as an existing project.
3. Allow Gradle sync to finish.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, from a terminal with Gradle 8.9 installed, run `gradle assembleDebug` from this folder. Android Gradle Plugin 8.7.3 is configured.

## Printer setup
Pair the Bluetooth thermal printer from Android Settings first. In the app, complete a sale and tap **Print Last Receipt (Bluetooth)**. This implementation targets printers that expose the standard Bluetooth Serial Port Profile (SPP) and understand basic ESC/POS text/cut commands. Printer models vary.

## Notes
- All data is stored locally on the device. Uninstalling the app or clearing its data can remove records; use Android device backups/export before relying on it for business records.
- Sales report's “last 24 hours” is a rolling 24-hour total, not a calendar-day total.
- This is a starter POS, not certified accounting software. Validate prices, stock and receipts before live use. It does not calculate GST.
